const enc=new TextEncoder(),hex=b=>Array.from(new Uint8Array(b),n=>n.toString(16).padStart(2,'0')).join('');
async function hash(s){return hex(await crypto.subtle.digest('SHA-256',enc.encode(s)))}
async function sign(s,secret){const k=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',k,enc.encode(s)))}
function equal(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0}
const attempts=new Map(),secure={'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'DENY'};
const res=(body,status=200,headers={})=>new Response(body,{status,headers:{...secure,...headers}});
function gate(error=''){return res(`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>抬头，下一站是你</title><style>body{margin:0;min-height:100svh;display:grid;place-items:center;background:#f4efe4;color:#30483e;font-family:system-ui}main{width:min(80%,360px);padding:40px 0}small{letter-spacing:3px}h1{font-size:36px;line-height:1.5}p{line-height:1.9;color:#6e776c}input,button{box-sizing:border-box;width:100%;padding:16px;border-radius:12px;font:inherit}input{border:1px solid #c8cebe;background:#fffaf1}button{margin-top:16px;border:0;background:#30483e;color:white}label{display:block;margin:30px 0 12px}.error{color:#985746}</style><main><small>OUR LITTLE JOURNEY</small><h1>抬头，<br>下一站是你。</h1><p>这是一段属于我们的旅程。<br>输入约好的密码，就从相遇的那页开始。</p><form action="/login" method="post"><label for="password">我们的通行密码</label><input id="password" name="password" type="password" required maxlength="128" autocomplete="current-password"><button>翻开我们的故事 ↗</button><p class="error" role="status">${error}</p></form></main></html>`,200,{'Content-Type':'text/html; charset=utf-8','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'"})}
export async function middleware(context){
const {request,env}=context;
const u=new URL(request.url);if(!env.GAME_PASSWORD||!env.SESSION_SECRET)return res('访问保护尚未配置',503);
if(u.pathname==='/robots.txt')return res('User-agent: *\nDisallow: /',200,{'Content-Type':'text/plain'});
if(u.pathname==='/_upload')return res('Forbidden',403);
if(u.pathname==='/login'&&request.method==='POST'){
if(request.headers.get('Origin')!==u.origin)return res('Forbidden',403);
const ip=request.headers.get('CF-Connecting-IP')||'unknown',now=Date.now(),a=attempts.get(ip);if(a&&a.until>now&&a.count>=12)return gate('尝试次数较多，请十分钟后再试。');
if(Number(request.headers.get('Content-Length')||0)>2048)return res('Too large',413);
const form=await request.formData(),password=String(form.get('password')||'');if(!equal(await hash(password),await hash(env.GAME_PASSWORD))){if(attempts.size>5000)attempts.clear();attempts.set(ip,{count:a&&a.until>now?a.count+1:1,until:a&&a.until>now?a.until:now+600000});return gate('密码没有对上，再想一想我们的约定。')}
attempts.delete(ip);const expiry=String(Math.floor(now/1000)+604800),token=expiry+'.'+await sign(expiry,env.SESSION_SECRET);return res(null,303,{Location:'/', 'Set-Cookie':`our_journey=${token}; Path=/; Max-Age=604800; HttpOnly; Secure; SameSite=Strict`})}
if(u.pathname==='/logout')return res(null,303,{Location:'/', 'Set-Cookie':'our_journey=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict'});
const cookie=(request.headers.get('Cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('our_journey='))?.slice(12)||'', [expiry,sig]=cookie.split('.');
const valid=/^\d+$/.test(expiry||'')&&Number(expiry)>Date.now()/1000&&Number(expiry)<Date.now()/1000+604801&&equal(sig,await sign(expiry,env.SESSION_SECRET));
if(!valid)return (u.pathname==='/'||u.pathname==='/login'&&request.method==='GET')?gate():res('请输入密码后访问',401);
if(!['GET','HEAD'].includes(request.method))return res('Method not allowed',405);
let key;try{key=decodeURIComponent(u.pathname).slice(1)||'index.html'}catch{return res('Bad path',400)}if(key.includes('..')||key.startsWith('.')||key.includes('\\'))return res('Not found',404);
const upstream=await context.next();const h=new Headers(upstream.headers);for(const [k,v] of Object.entries(secure))h.set(k,v);return new Response(upstream.body,{status:upstream.status,headers:h});
}
export const config={matcher:['/:path*']};
