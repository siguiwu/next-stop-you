# 抬头，下一站是你

TypeScript + React + PixiJS + Vite 手机竖屏互动回忆游戏，8 章。

## 本地开发

安装 Node.js，运行 npm ci，然后 npm run dev。npm run build 输出 dist。

## 素材

此仓库仅包含游戏源码。私人照片、视频、商业歌曲、原始素材与部署凭据不上传。运行完整版本时，将本地 game/public/media 的文件复制到本项目 public/media；缺少素材会影响画面和声音。

## 文件

- src/story.ts：故事章节和旁白。
- src/LibraryScene.tsx、PhotoScene.tsx：场景与交互。
- src/PhotoPuzzle.tsx：照片拼图。
- src/music.ts：六首背景音乐引用。
- middleware.js：腾讯云服务器密码保护。

## 部署

腾讯云 EdgeOne 使用 edgeone.json 构建。GAME_PASSWORD 和 SESSION_SECRET 在托管平台配置；不得写入源码。普通静态托管不执行 middleware.js，不能据此前端页面认定照片已受密码保护。

## 隐私

源码包含私人故事，请保持仓库私有。没有附带商业歌曲授权或素材再分发许可。
